<?php
/**
 * Hooks used for Page
 */
add_action( 'reen_page', 'reen_page_header',           10 );
add_action( 'reen_page', 'reen_page_content',          20 );