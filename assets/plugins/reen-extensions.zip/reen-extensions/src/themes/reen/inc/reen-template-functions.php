<?php
/**
 * Reen template functions.
 *
 * @package reen
 */
require_once get_template_directory() . '/inc/template-tags/blog.php';
require_once get_template_directory() . '/inc/template-tags/page.php';