<?php
/**
 * Plugin Name: Reen Gutenberg Blocks
 * Plugin URI: https://wpreengb.com
 * Description: Gutenberg Blocks for Reen WordPress Theme
 * Author: MadrasThemes
 * Author URI: https://themeforest.net/user/madrasthemes/portfolio
 * Text Domain: reengb
 * Version: 0.0.246
 *
 * @package ReenGB
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

defined( 'REENGB_VERSION' ) || define( 'REENGB_VERSION', '0.0.246' );
defined( 'REENGB_FILE' ) || define( 'REENGB_FILE', __FILE__ );
defined( 'REENGB_I18N' ) || define( 'REENGB_I18N', 'reengb' ); // Plugin slug.

/********************************************************************************************
 * Activation & PHP version checks.
 ********************************************************************************************/

if ( ! function_exists( 'reengb_php_requirement_activation_check' ) ) {

    /**
     * Upon activation, check if we have the proper PHP version.
     * Show an error if needed and don't continue with the plugin.
     *
     * @since 1.9
     */
    function reengb_php_requirement_activation_check() {
        if ( version_compare( PHP_VERSION, '5.3.0', '<' ) ) {
            deactivate_plugins( basename( __FILE__ ) );
            wp_die(
                sprintf(
                    __( '%s"ReenGB" can not be activated. %s It requires PHP version 5.3.0 or higher, but PHP version %s is used on the site. Please upgrade your PHP version first ✌️ %s Back %s', REENGB_I18N ),
                    '<strong>',
                    '</strong><br><br>',
                    PHP_VERSION,
                    '<br /><br /><a href="' . esc_url( get_dashboard_url( get_current_user_id(), 'plugins.php' ) ) . '" class="button button-primary">',
                    '</a>'
                )
            );
        }
    }
    register_activation_hook( __FILE__, 'reengb_php_requirement_activation_check' );
}

/**
 * Always check the PHP version at the start.
 * If the PHP version isn't sufficient, don't continue to prevent any unwanted errors.
 *
 * @since 1.9
 */
if ( version_compare( PHP_VERSION, '5.3.0', '<' ) ) {
    if ( ! function_exists( 'reengb_php_requirement_notice' ) ) {
        function reengb_php_requirement_notice() {
            printf(
                '<div class="notice notice-error"><p>%s</p></div>',
                sprintf( __( '"ReenGB" requires PHP version 5.3.0 or higher, but PHP version %s is used on the site.', REENGB_I18N ), PHP_VERSION )
            );
        }
    }
    add_action( 'admin_notices', 'reengb_php_requirement_notice' );
    return;
}

/********************************************************************************************
 * END Activation & PHP version checks.
 ********************************************************************************************/

/**
 * Block Initializer.
 */
require_once( plugin_dir_path( __FILE__ ) . 'src/block/portfolio-megamenu/index.php' );
require_once( plugin_dir_path( __FILE__ ) . 'src/metabox.php' );
require_once( plugin_dir_path( __FILE__ ) . 'src/block/disabled-blocks.php' );
require_once( plugin_dir_path( __FILE__ ) . 'src/init.php' );
require_once( plugin_dir_path( __FILE__ ) . 'src/block/portfolio/index.php' );
require_once( plugin_dir_path( __FILE__ ) . 'src/block/post-carousel/index.php' );
require_once( plugin_dir_path( __FILE__ ) . 'src/block/testimonial-carousel/index.php' );
require_once( plugin_dir_path( __FILE__ ) . 'src/block/portfolio-carousel/index.php' );
require_once( plugin_dir_path( __FILE__ ) . 'src/block/shortcode/index.php' );