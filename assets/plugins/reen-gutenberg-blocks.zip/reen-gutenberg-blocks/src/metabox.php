<?php
if ( ! function_exists( 'reengb_register_meta_fields' ) ) {
    function reengb_register_meta_fields() {

        register_meta( 'post', '_gallery_images', array(
            'object_subtype' => 'post',
            'show_in_rest' => true,
            'type' => 'string',
            'single' => true,
            'auth_callback' => function() { 
                return current_user_can( 'edit_posts' );
            }
        ) );
        register_meta( 'post', '_audio_field', array(
            'object_subtype' => 'post',
            'show_in_rest' => true,
            'type' => 'string',
            'single' => true,
            'auth_callback' => function() { 
                return current_user_can( 'edit_posts' );
            }
        ) );
        register_meta( 'post', '_video_field', array(
            'object_subtype' => 'post',
            'show_in_rest' => true,
            'type' => 'string',
            'single' => true,
            'auth_callback' => function() { 
                return current_user_can( 'edit_posts' );
            }
        ) );
        register_meta( 'post', '_portfolio_style', array(
            'object_subtype' => 'jetpack-portfolio',
            'show_in_rest' => true,
            'type' => 'string',
            'single' => true,
            'auth_callback' => function() { 
                return current_user_can( 'edit_posts' );
            }
        ) );
        register_meta( 'post', '_portfolio_gallery_images', array(
            'object_subtype' => 'jetpack-portfolio',
            'show_in_rest' => true,
            'type' => 'string',
            'single' => true,
            'auth_callback' => function() { 
                return current_user_can( 'edit_posts' );
            }
        ) );
        register_meta( 'post', '_portfolio_audio_field', array(
            'object_subtype' => 'jetpack-portfolio',
            'show_in_rest' => true,
            'type' => 'string',
            'single' => true,
            'auth_callback' => function() { 
                return current_user_can( 'edit_posts' );
            }
        ) );
        register_meta( 'post', '_portfolio_video_field', array(
            'object_subtype' => 'jetpack-portfolio',
            'show_in_rest' => true,
            'type' => 'string',
            'single' => true,
            'auth_callback' => function() { 
                return current_user_can( 'edit_posts' );
            }
        ) );
        register_meta( 'post', '_bodyClasses', array(
            'object_subtype' => 'page',
            'show_in_rest' => true,
            'type' => 'string',
            'single' => true,
            'auth_callback' => function() { 
                return current_user_can( 'edit_pages' );
            }
        ) );
        register_meta( 'post', '_disableContainer', array(
            'object_subtype' => 'page',
            'show_in_rest' => true,
            'type' => 'boolean',
            'single' => true,
            'auth_callback' => function() { 
                return current_user_can( 'edit_pages' );
            }
        ) );
        register_meta( 'post', '_hidePageHeader', array(
            'object_subtype' => 'page',
            'show_in_rest' => true,
            'type' => 'boolean',
            'single' => true,
            'auth_callback' => function() { 
                return current_user_can( 'edit_pages' );
            }
        ) );
    }
    add_action('init', 'reengb_register_meta_fields');
}
