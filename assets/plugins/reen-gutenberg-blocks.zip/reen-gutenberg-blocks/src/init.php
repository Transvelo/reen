<?php
/**
 * Blocks Initializer
 *
 * Enqueue CSS/JS of all the blocks.
 *
 * @since   0.1
 * @package ReenGB
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! function_exists( 'reengb_block_assets' ) ) {

    /**
    * Enqueue block assets for both frontend + backend.
    *
    * @since 0.1
    */
    function reengb_block_assets() {

        // Frontend block styles.
        wp_enqueue_style(
            'rgb-style-css',
            plugins_url( 'dist/frontend_blocks.css', REENGB_FILE ),
            array(),
            REENGB_VERSION
        );

        
        // Frontend only scripts.
        if ( ! is_admin() ) {
            wp_enqueue_script(
                'rgb-block-frontend-js',
                plugins_url( 'dist/frontend_blocks.js', REENGB_FILE ),
                array(),
                REENGB_VERSION
            );
        }

        if( has_block( 'rgb/tabs' ) ) {
            wp_enqueue_script( 'jquery-easytabs' );
        }
        
    }
    add_action( 'enqueue_block_assets', 'reengb_block_assets' );
}

if ( ! function_exists( 'reengb_block_editor_assets' ) ) {

    /**
     * Enqueue block assets for backend editor.
     *
     * @since 0.1
     */
    function reengb_block_editor_assets() {

        // Backend editor scripts: common vendor files.
        wp_enqueue_script(
            'rgb-block-js-vendor',
            plugins_url( 'dist/editor_vendor.js', REENGB_FILE ),
            array(),
            REENGB_VERSION
        );

        // Backend editor scripts: formats.
        wp_enqueue_script(
            'rgb-format-js',
            plugins_url( 'dist/editor_formats.js', REENGB_FILE ),
            array( 'wp-rich-text' ),
            REENGB_VERSION
        );

        // Backend editor scripts: blocks.
        wp_enqueue_script(
            'rgb-block-js',
            plugins_url( 'dist/editor_blocks.js', REENGB_FILE ),
            array( 'rgb-block-js-vendor', 'wp-blocks', 'wp-element', 'wp-components', 'wp-editor', 'wp-i18n', 'owl-carousel', 'reen-scripts'),
            REENGB_VERSION
        );

        // Backend editor scripts: meta.
        wp_enqueue_script(
            'rgb-meta-js',
            plugins_url( 'dist/editor_meta.js', REENGB_FILE ),
            array( 'wp-plugins', 'wp-edit-post', 'wp-i18n', 'wp-element' ),
            REENGB_VERSION
        );

        // Add translations.
        wp_set_script_translations( 'rgb-block-js', REENGB_I18N );

        // Backend editor only styles.
        wp_enqueue_style(
            'rgb-block-editor-css',
            plugins_url( 'dist/editor_blocks.css', REENGB_FILE ),
            array( 'wp-edit-blocks' ),
            REENGB_VERSION
        );

        global $content_width;
        wp_localize_script( 'rgb-block-js', 'reengb', array(
            'srcUrl' => untrailingslashit( plugins_url( '/', REENGB_FILE ) ),
            'contentWidth' => isset( $content_width ) ? $content_width : 900,
            'themeUrl'       => get_template_directory_uri(),
            'i18n' => REENGB_I18N,
            'disabledBlocks' => reengb_get_disabled_blocks(),

            // Overridable default primary color for buttons and other blocks.
            'primaryColor' => get_theme_mod( 's_primary_color', '#2091e1' ),
        ) );
    }
    add_action( 'enqueue_block_editor_assets', 'reengb_block_editor_assets' );
}

if ( ! function_exists( 'reengb_load_plugin_textdomain' ) ) {

    /**
     * Translations.
     */
    function reengb_load_plugin_textdomain() {
        load_plugin_textdomain( 'reengb' );
    }
    add_action( 'plugins_loaded', 'reengb_load_plugin_textdomain' );
}

if ( ! function_exists( 'reengb_block_category' ) ) {

    /**
     * Add our custom block category for ReenGB blocks.
     *
     * @since 0.6
     */
    function reengb_block_category( $categories, $post ) {
        return array_merge(
            $categories,
            array(
                array(
                    'slug' => 'reengb',
                    'title' => __( 'ReenGB', REENGB_I18N ),
                ),
                array(
                    'slug'  => 'reengb-carousel',
                    'title' => __( 'ReenGB Carousel', REENGB_I18N ),
                ),
            )
        );
    }
    add_filter( 'block_categories', 'reengb_block_category', 10, 2 );
}

if ( ! function_exists( 'reengb_get_assets_url' ) ) {
    function reengb_get_assets_url() {
        return get_template_directory_uri() . '/assets/';
    }
}

if ( ! function_exists( 'reengb_add_required_block_styles' ) ) {

    /**
     * Adds the required global styles for ReenGB blocks.
     *
     * @since 1.3
     */
    function reengb_add_required_block_styles() {
        global $content_width;
        $full_width_block_inner_width = isset( $content_width ) ? $content_width : 900;

        $custom_css = ':root {
            --content-width: ' . esc_attr( $full_width_block_inner_width ) . 'px;
        }';
        wp_add_inline_style( 'rgb-style-css', $custom_css );
    }
    add_action( 'enqueue_block_assets', 'reengb_add_required_block_styles', 11 );
}
