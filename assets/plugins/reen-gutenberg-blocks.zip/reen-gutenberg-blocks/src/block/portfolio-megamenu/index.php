<?php
/**
 * Server-side rendering of the `fgb/news-blog` block.
 *
 * @package ReenGB
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Renders the `rgb/portfolio-megamenu` block on server.
 *
 * @since 1.7
 *
 * @param array $attributes The block attributes.
 *
 * @return string Returns the post content with latest posts added.
 */
if ( ! function_exists( 'reengb_render_portfolio_posts_block' ) ) {
    function reengb_render_portfolio_posts_block( $attributes ) {
        
        $query_args = array(
            'post_type'   => 'jetpack-portfolio', 
            'numberposts' => ! empty( $attributes['postsToShow'] ) ? $attributes['postsToShow'] : '',
            'post_status' => 'publish',
            'order' => ! empty( $attributes['order'] ) ? $attributes['order'] : '',
            'orderby' => ! empty( $attributes['orderBy'] ) ? $attributes['orderBy'] : '',
            'include'     => ( ! empty( $attributes['posts'] ) && is_array($attributes['posts']) ) ? array_column($attributes['posts'], 'id') : '',
            'posts_per_page' => $attributes['design'] == 'style-1' ? 1 : '',
        );

        $recent_posts = wp_get_recent_posts( $query_args );

        $posts_markup = '';
        $props = array( 'attributes' => array() );

        foreach ( $recent_posts as $index => $post ) {
            $post_id = $post['ID'];

            $content = get_post($post_id);

            // Content.
            $post_content = wp_strip_all_tags( $content->post_content, true );

            // Featured Image.
            $post_featured_image = get_the_post_thumbnail_url( $post_id );

            // Post link.
            $post_link = get_permalink( $post_id );
            
            
            /**
             * This is the default style.
             */
            $post_markup = '';

            if ( $attributes['design'] == 'style-1' ) {
                $post_markup  = '<figure>';
                $post_markup .= '<div class="icon-overlay icn-link">';
                $post_markup .= '<a href="' . esc_url( $post_link ) . '">';
                $post_markup .= '<img src="' . esc_url( $post_featured_image ) . '" alt="img">';
                $post_markup .= '</a>';
                $post_markup .= '</div>';
                $post_markup .= '<figcaption>';
                if ( ! empty( $post_content ) ) {
                    $post_markup .= '<p>' . wp_kses_post( $post_content ) . '</p>';
                }
                $post_markup .= '<a href="' . esc_url( $post_link ) . '" class="btn">' . $attributes['readMoreButton'] . '</a>';
                $post_markup .= '</figcaption>';
                $post_markup .= '</figure>';
            }
            else {
                if ( $attributes['design'] == 'style-2' ) {
                    $post_markup .= '<div class="col-6 thumb">';
                    $post_markup .= '<figure class="icon-overlay icn-link">';
                    $post_markup .= '<a href="' . esc_url( $post_link ) . '">';
                    $post_markup .= '<img src="' . esc_url( $post_featured_image ) . '" alt="img">';
                    $post_markup .= '</a>';
                    $post_markup .= '</figure>';
                    $post_markup .= '</div>';
                }
            }

            $posts_markup .= wp_kses_post( $post_markup );
        }
            
        return ( $attributes['design'] == 'style-2' ? '<div class="row thumbs gap-xs">' . $posts_markup . '</div>'  : $posts_markup );
    }
}


if ( ! function_exists( 'reengb_register_portfolio_posts_block' ) ) {
    /**
     * Registers the `rgb/portfolio-megamenu` block on server.
     */
    function reengb_register_portfolio_posts_block() {
        if ( ! function_exists( 'register_block_type' ) ) {
            return;
        }

        register_block_type(
            'rgb/portfolio-megamenu',
            array(
                'attributes' => array(
                    'className' => array(
                        'type' => 'string',
                    ),
                    'order' => array(
                        'type' => 'string',
                        'default' => 'desc',
                    ),
                    'orderBy' => array(
                        'type' => 'string',
                        'default' => 'date',
                    ),
                    'postsToShow' => array(
                        'type' => 'number',
                        'default' => 9,
                    ),
                    'readMoreButton' => array(
                        'type' => 'string',
                        'default' => 'View Project',
                    ),
                    'design' => array(
                        'type' => 'string',
                        'default' => 'style-1',
                    ),
                    'posts'=> array(
                        'type' => 'array',
                        'items' => array(
                          'type' => 'object'
                        ),
                        'default' => [],
                    ),
                ),
                'render_callback' => 'reengb_render_portfolio_posts_block',
            )
        );
    }
    add_action( 'init', 'reengb_register_portfolio_posts_block' );
}