<?php
/**
 * Server-side rendering of the `rgb/portfolio-carousel` block.
 *
 * @package FrontGB
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Renders the `rgb/portfolio-carousel` block on server.
 *
 * @since 1.7
 *
 * @param array $attributes The block attributes.
 *
 * @return string Returns the post content with latest posts added.
 */
if ( ! function_exists( 'reengb_render_hero_portfolio_slider_block' ) ) {
    function reengb_render_hero_portfolio_slider_block( $attributes ) {

        $recent_posts = wp_get_recent_posts(
            array(
                'post_type'   => 'jetpack-portfolio', 
                'numberposts' => ! empty( $attributes['postsToShow'] ) ? $attributes['postsToShow'] : '',
                'post_status' => 'publish',
                'order' => ! empty( $attributes['order'] ) ? $attributes['order'] : '',
                'orderby' => ! empty( $attributes['orderBy'] ) ? $attributes['orderBy'] : '',
                'include'     => ( ! empty( $attributes['posts'] ) && is_array($attributes['posts']) ) ? array_column($attributes['posts'], 'id') : '',
                'tax_query' => ( ! empty( $attributes['portfolio_types'] ) && is_array($attributes['portfolio_types']) ) ? array(
                    array(
                        'taxonomy' => 'jetpack-portfolio-type',
                        'field'    => 'slug',
                        'terms'     => $attributes['portfolio_types'], 
                        'operator' => 'IN'
                    )
                ) :  array()
            )
        );

        $posts_markup = '';
        $props = array( 'attributes' => array() );

        $row_classes = '';
        $row_classes = ( isset($attributes['rowClasses']) ? $attributes['rowClasses'] : '' ); 

        foreach ( $recent_posts as $index => $post ) {
            $post_id = $post['ID'];
            //$post_id = $post->ID;

            // Title.
            $post_title = get_the_title( $post_id );


            // Featured image.
            $featured_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post_id ), 'full' );

            if ( $featured_image ){
                $image ='<img src=' . esc_url($featured_image[0]) . ' alt=""/>';
            } else {
                $image ='<img src="' . untrailingslashit( plugins_url( '/', REENGB_FILE ) ) . '/dist/images/block-portfolio-carousel-work01-lg.89f53c2.jpg' . '" alt="" />';
            }
                    

            // Post Link
            $post_link = get_permalink( $post_id );

            $post_terms = get_the_terms( $post_id, 'jetpack-portfolio-type' );

            $category_class = '';
            if( is_array ($post_terms) ) {
                $category_class .= implode(' / ', wp_list_pluck( $post_terms, 'slug') );
            }

    
            /**
             * This is the default basic style.
             */
            $post_markup  = '<div class="item">';
            $post_markup .= '<a href="' . esc_url( $post_link ) . '">';
            $post_markup .= '<figure>';
            if ($attributes['displayCaption']) {
                $post_markup .= '<figcaption class="text-overlay"><div class="info">';
                if ($attributes['displayPostTitle']) {
                    $post_markup .= '<h2>' . wp_kses_post( $post_title ) . '</h2>';
                } 
                if ($attributes['displayPostCategory']) {
                    $post_markup .= '<p>' . esc_attr( $category_class ) .'</p>';
                } 
                $post_markup .= '</div></figcaption>';
            }
            $post_markup .= $image;
            $post_markup .= '</figure>';
            $post_markup .= '</a>';
            $post_markup .= '</div>';

            $post_markup = apply_filters( 'reengb/hero-slider-2_save', $post_markup, $attributes );
            $posts_markup .= $post_markup;
        }
            

        $block_content  = '<div class="' . esc_attr( $attributes['enableContainer'] ? 'container' : 'no-container' ) . '"><div class="row ' . esc_attr( $row_classes ) .'"><div class="col-md-12"><div id="owl-featured-works" data-owl-carousel="' . htmlspecialchars( json_encode( $attributes['carouselOptions']), ENT_QUOTES, 'UTF-8' ) . '" class="owl-theme portfolio-carousel owl-carousel ' . esc_attr( isset( $attributes['carouselOptions']['outerNav']) && !empty( $attributes['carouselOptions']['outerNav']) ? $attributes['carouselOptions']['outerNav'] : '' ) . ' ' . ( isset ( $attributes['carouselOptions']['owlNavSize']) && !empty($attributes['carouselOptions']['owlNavSize']) ? $attributes['carouselOptions']['owlNavSize'] : '' ) . ' ' . esc_attr( isset( $attributes['carouselOptions']['owlItemGap']) && !empty($attributes['carouselOptions']['owlItemGap']) ? $attributes['carouselOptions']['owlItemGap'] : '' ) . ' ' . esc_attr( isset( $attributes['carouselOptions']['owlInnerPag']) && !empty($attributes['carouselOptions']['owlInnerPag']) ? 'owl-inner-pagination' : '' ) . '">';
        $block_content .= wp_kses_post( $posts_markup );
        $block_content .= '</div></div></div></div>';

        return $block_content;
        
    }
}

if ( ! function_exists( 'reengb_register_hero_portfolio_slider_block' ) ) {
    /**
     * Registers the `rgb/portfolio-carousel` block on server.
     */
    function reengb_register_hero_portfolio_slider_block() {
        if ( ! function_exists( 'register_block_type' ) ) {
            return;
        }

        register_block_type(
            'rgb/portfolio-carousel',
            array(
                'attributes' => array(
                    'className' => array(
                        'type' => 'string',
                    ),
                    'enableContainer' => array (
                        'type' => 'boolean',
                        'default' => true,
                    ),
                    'design' => array (
                        'type' => 'string',
                        'default' => 'style-1',
                    ),
                    'postsToShow' => array(
                        'type' => 'number',
                        'default' => 9,
                    ),
                    'order' => array(
                        'type' => 'string',
                        'default' => 'desc',
                    ),
                    'orderBy' => array(
                        'type' => 'string',
                        'default' => 'date',
                    ),

                    'portfolio_types'=> array(
                        'type' => 'array',
                        'items' => array(
                          'type' => 'string'
                        ),
                        'default' => [],
                    ),
                    'displayCaption' => array(
                        'type' => 'boolean',
                        'default' => true,
                    ),
                    'displayPostTitle' => array(
                        'type' => 'boolean',
                        'default' => true,
                    ),
                    'displayPostCategory' => array(
                        'type' => 'boolean',
                        'default' => true,
                    ),
                    'posts'=> array(
                        'type' => 'array',
                        'items' => array(
                          'type' => 'object'
                        ),
                        'default' => [],
                    ),
                    'rowClasses' => array(
                        'type' => 'string',
                    ),
                    
                    'carouselOptions'=> array (
                        'type'      => 'object',
                        'default'   => array(
                            'autoplay'    => true,
                            'autoplayTimeout'       => 5000,
                            'autoplayHoverPause'   => true,
                            'rewind'         => true,
                            'dots'           => true,
                            'nav'            => true,
                            'items'          => 1,
                            'navText'        => array( '<i class="icon-left-open-mini"></i>', '<i class="icon-right-open-mini"></i>'),
                            'animateIn'   => 'fadeIn',
                            'animateOut'    => 'fadeOut',
                            'responsive'    => array(
                                '0'         => array( 'items' => 1 ),
                                '480'       => array( 'items' => 2 ),
                                '768'       => array( 'items' => 2 ),
                                '992'       => array( 'items' => 1 ),
                                '1200'      => array( 'items' => 1 ),
                            ),
                            'outerNav' => 'owl-outer-nav',
                            'owlNavSize' => 'owl-ui-md',
                            'owlItemGap' => 'owl-item-gap',
                            'owlInnerPag' => true
                        ),
                    ),
                    
                ),
                'render_callback' => 'reengb_render_hero_portfolio_slider_block',
            )
        );
    }
    add_action( 'init', 'reengb_register_hero_portfolio_slider_block' );
}

if ( ! function_exists( 'reengb_portfolio_carousel_rest_fields' ) ) {
    /**
     * Add more data in the REST API that we'll use in the blog post.
     *
     * @since 1.7
     */
    function reengb_portfolio_carousel_rest_fields() {

        // Featured image urls.
        register_rest_field( 'jetpack-portfolio', 'featured_image_urls',
            array(
                'get_callback' => 'reengb_portfolio_carousel_featured_image_urls',
                'update_callback' => null,
                'schema' => array(
                    'description' => __( 'Different sized featured images' ),
                    'type' => 'array',
                ),
            )
        );

        //Category name.
        register_rest_field( 'jetpack-portfolio', 'category',
            array(
                'get_callback' => 'reengb_portfolio_carousel_category_list',
                'update_callback' => null,
                'schema' => array(
                    'description' => __( 'Category' ),
                    'type' => 'string',
                ),
            )
        );

    }
    add_action( 'init', 'reengb_portfolio_carousel_rest_fields' );
}

if ( ! function_exists( 'reengb_portfolio_carousel_featured_image_urls' ) ) {
    /**
     * Get the different featured image sizes that the blog will use.
     *
     * @since 1.7
     */
    function reengb_portfolio_carousel_featured_image_urls( $object, $field_name, $request ) {
        $image = wp_get_attachment_image_src( $object['featured_media'], 'full', false );
        return array(
            'full' => is_array( $image ) ? $image : '',
        );
    }
}

if ( ! function_exists( 'reengb_portfolio_carousel_category_list' ) ) {
    /**
     * Get the category.
     *
     * @since 1.7
     */
    function reengb_portfolio_carousel_category_list( $items ) {

        $portfolio_type = get_the_terms( get_the_ID(), 'jetpack-portfolio-type' );

        if( is_array( $portfolio_type ) ) return implode('/', wp_list_pluck( $portfolio_type, 'name'));
        return;
    }
}

