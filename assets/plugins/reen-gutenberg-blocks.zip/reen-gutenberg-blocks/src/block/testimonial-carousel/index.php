<?php
/**
 * Server-side rendering of the `rgb/testimonial-carousel` block.
 *
 * @package ReenGB
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Renders the `rgb/testimonial-carousel` block on server.
 *
 * @since 1.7
 *
 * @param array $attributes The block attributes.
 *
 * @return string Returns the post content with latest posts added.
 */
if ( ! function_exists( 'reengb_render_testimonial_carousel_block' ) ) {
    function reengb_render_testimonial_carousel_block( $attributes ) {
        $recent_posts = wp_get_recent_posts(
            array(
                'post_type'   => 'jetpack-testimonial', 
                'numberposts' => ! empty( $attributes['postsToShow'] ) ? $attributes['postsToShow'] : '',
                'post_status' => 'publish',
                'order'       => ! empty( $attributes['order'] ) ? $attributes['order'] : '',
                'orderby'     => ! empty( $attributes['orderBy'] ) ? $attributes['orderBy'] : '',
                'include'     => ( ! empty( $attributes['posts'] ) && is_array($attributes['posts']) ) ? array_column($attributes['posts'], 'id') : '',
            )
        );

        $posts_markup = '';

        foreach ( $recent_posts as $index => $post ) {
            $post_id = $post['ID'];

            // Author.
            $Author = get_the_title( $post_id );

            // Content.
            $content = wp_strip_all_tags( get_post_field( 'post_content', $post_id ), true );

            $post_markup  = '<div class="item">';
            $post_markup .= '<blockquote>';
            $post_markup .= '<p>' . esc_html( $content ) . '</p>';
            $post_markup .= '<footer>' . esc_html( $Author ) . '</footer>';
            $post_markup .= '</blockquote>';
            $post_markup .= '</div>';

            $posts_markup .= $post_markup;
        }
        
        
        $block_content  = '<div class="' . esc_attr( $attributes['enableContainer'] ? 'container' : 'no-container' ) . '"><div class="row"><div class="col-lg-8 col-md-9 mx-auto text-center"><div data-owl-carousel="' . htmlspecialchars( json_encode( $attributes['carouselOptions']), ENT_QUOTES, 'UTF-8' ) . '" class="owl-carousel owl-outer-nav owl-ui-md owl-theme" id="owl-testimonials">';
        $block_content .= $posts_markup;

        $block_content .= '</div></div></div></div>';
        
        return $block_content;


    
    }
}

if ( ! function_exists( 'reengb_register_testimonial_carousel_block' ) ) {
    /**
     * Registers the `rgb/testimonial-carousel` block on server.
     */
    function reengb_register_testimonial_carousel_block() {
        if ( ! function_exists( 'register_block_type' ) ) {
            return;
        }

        register_block_type(
            'rgb/testimonial-carousel',
            array(
                'attributes' => array(
                    'className' => array(
                        'type' => 'string',
                    ),
                    'order' => array(
                        'type' => 'string',
                        'default' => 'asc',
                    ),
                    'orderBy' => array(
                        'type' => 'string',
                        'default' => 'title',
                    ),
                    'postsToShow' => array(
                        'type' => 'number',
                        'default' => 4,
                    ),
                    'displayAuthor' => array(
                        'type' => 'boolean',
                        'default' => true,
                    ),
                
                    'displayQuote' => array(
                        'type' => 'boolean',
                        'default' => true,
                    ),
                    'enableContainer' => array(
                        'type' => 'boolean',
                        'default' => true,
                    ),
                    'posts'=> array(
                        'type' => 'array',
                        'items' => array(
                          'type' => 'object'
                        ),
                        'default' => [],
                    ),
                    'carouselOptions'=> array (
                        'type'      => 'object',
                        'default'   => array(
                            'autoplay'    => true,
                            'autoplayTimeout'       => 5000,
                            'autoplayHoverPause'   => true,
                            'rewind'         => true,
                            'dots'           => true,
                            'nav'            => true,
                            'items'          => 1,
                            'navText'        => array( '<i class="icon-left-open-mini"></i>', '<i class="icon-right-open-mini"></i>' )
                        ),
                    ),
                ),
                'render_callback' => 'reengb_render_testimonial_carousel_block',
            )
        );
    }
    add_action( 'init', 'reengb_register_testimonial_carousel_block' );
}


