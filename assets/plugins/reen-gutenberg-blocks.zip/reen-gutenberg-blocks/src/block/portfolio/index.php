<?php
/**
 * Server-side rendering of the `fgb/portfolio` block.
 *
 * @package Reengb
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Renders the `fgb/portfolio` block on server.
 *
 * @since 1.7
 *
 * @param array $attributes The block attributes.
 *
 * @return string Returns the post content with latest posts added.
 */
if ( ! function_exists( 'reengb_render_portfolio_block' ) ) {
    function reengb_render_portfolio_block( $attributes ) {
        $recent_posts = wp_get_recent_posts(
            array(
                'post_type'   => 'jetpack-portfolio', 
                'numberposts' => ! empty( $attributes['postsToShow'] ) ? $attributes['postsToShow'] : '',
                'post_status' => 'publish',
                'order' => ! empty( $attributes['order'] ) ? $attributes['order'] : '',
                'orderby' => ! empty( $attributes['orderBy'] ) ? $attributes['orderBy'] : '',
                'include'     => ( ! empty( $attributes['posts'] ) && is_array($attributes['posts']) ) ? array_column($attributes['posts'], 'id') : '',
                'tax_query' => ( ! empty( $attributes['portfolio_tags'] ) && is_array($attributes['portfolio_tags']) ) ? array(
                    array(
                        'taxonomy' => 'jetpack-portfolio-tag',
                        'field'    => 'slug',
                        'terms'    => $attributes['portfolio_tags'],
                        'operator' => 'IN',
                    ) 
                ) :  array()
            )
        );

        $ulClass = 'isotope items';
            if ( ( $attributes['design'] == 'style-1' )  || ( $attributes['design'] == 'style-2' ) ) { 
               $ulClass .=  ' col-3-custom';
            }
            if ( ( $attributes['design'] == 'style-3' ) || ( $attributes['design'] == 'style-4' ) ) { 
                $ulClass .=  ' col-4-custom';
            }
            if ( $attributes['design'] == 'style-5' ) { 
                $ulClass .=  ' fullscreen';
            }

        $containerclass = '';

            if ($attributes['enableContainer'] === true) { 
              $containerclass .=  'container';
            }
            if (($attributes['design'] !== 'style-5') && ( $attributes['design'] !== 'style-6') ) { 
              $containerclass .=  ' inner';
            }
            if ($attributes['design'] === 'style-5' ) { 
              $containerclass .=  ' inner-bottom-xs';
            }

        $posts_markup = '';
        $props = array( 'attributes' => array() );


        $singlecat = '';

        $terms = get_terms('jetpack-portfolio-type');

        foreach ( $terms as $term ) {
            $singlecat .=  '<li><a href= "#" data-filter=".'. $term->slug . '">' . esc_html( $term->name ) . '</a></li>';
        }

        $posts_markup = '';
        $props = array( 'attributes' => array() );

        foreach ( $recent_posts as $index => $post ) {
            $post_id = $post['ID'];

            // Title.
            $Title = get_the_title( $post_id );

            $featured_image = get_the_post_thumbnail_url( $post_id );

            // Link.
            $Link = get_permalink( $post_id );

            // Image

            if ( $featured_image ){
                $image ='<img src=' . esc_url($featured_image) . ' alt="Image Description"/>';
            } else {
                $image ='<img src="' . untrailingslashit( plugins_url( '/', REENGB_FILE ) ) . '/dist/images/block-portfolio-work01.2dc6232.jpg' . '" alt="" />';
            }

            $post_terms = get_the_terms( $post_id, 'jetpack-portfolio-type' );

            $category_class = '';

            $categories = '';

            if( is_array ($post_terms) ) {

                $length = count($post_terms);

                foreach ( $post_terms as $i => $post_term ) {
                    $category_class .= $post_term->slug . ' ';
                    $categories .= $post_term->name . ( $i == $length - 1 ? '' : '/' );
                }
            }

             if ( $attributes['design'] !== 'style-6' ) {                
                $post_markup = '<li class="item thumb  ' . esc_attr( $category_class ) . ' ">';
                if ( $attributes['design'] === 'style-1' || $attributes['design'] === 'style-3' || $attributes['design'] === 'style-5') {
                    $post_markup .= '<a href="' . esc_url( $Link ) . '">';
                    $post_markup .= '<figure>';
                    $post_markup .= '<figcaption class="text-overlay">';
                    $post_markup .= '<div class="info">';
                    $post_markup .= '<h4>' . esc_html( $Title ) .'</h4>';
                    $post_markup .= '<p>' . esc_attr( $categories ) .'</p>';
                    $post_markup .= '</div>';
                    $post_markup .= '</figcaption>';
                    $post_markup .= $image;
                    $post_markup .= '</figure>';
                    $post_markup .= '</a>';
                }
                if ( $attributes['design'] === 'style-2' || $attributes['design'] === 'style-4') {
                    $post_markup .= '<figure>';
                    $post_markup .= '<div class="icon-overlay icn-link">';
                    $post_markup .= '<a href="' . esc_url( $Link ) . '">';
                    $post_markup .= $image;
                    $post_markup .= '</a>';
                    $post_markup .= '</div>';
                    $post_markup .= '<figcaption class="bordered no-top-border">';
                    $post_markup .= '<div class="info">';
                    $post_markup .= '<h4><a href="' . esc_url( $Link ) . '">' . esc_html( $Title ) .'</a></h4>';
                    $post_markup .= '<p>' . esc_attr( $categories ) .'</p>';
                    $post_markup .= '</div>';
                    $post_markup .= '</figcaption>';
                    $post_markup .= '</figure>';
                }
                $post_markup .= '<li>';
            }
            if ( $attributes['design'] === 'style-6' ) {  
                $post_markup = '<div class="col-md-6 inner-top-sm">'; 
                $post_markup .= '<figure>';
                $post_markup .= '<div class="icon-overlay icn-link">';
                $post_markup .= '<a href="' . esc_url( $Link ) . '">';
                $post_markup .= $image;
                $post_markup .= '</a>';
                $post_markup .= '</div>';
                $post_markup .= '<figcaption class="bordered no-top-border">';
                $post_markup .= '<div class="info">';
                $post_markup .= '<h3><a href="' . esc_url( $Link ) . '">' . esc_html( $Title ) .'</a></h3>';
                $post_markup .= '<p>' . esc_attr( $categories ) .'</p>';
                $post_markup .= '</div>';
                $post_markup .= '</figcaption>';
                $post_markup .= '</figure>';
                $post_markup .= '</div>';
            }

            $posts_markup .= $post_markup . "\n";     
        }   

        $section_class = 'portfolio-block';
            if ( isset( $attributes['className'] ) ) {
                $section_class .=  ' ' . $attributes['className'];
            }

            if ( isset( $attributes['background'] ) ) {
                $section_class .= ' ' . $attributes['background'];
            }    

        if ( $attributes['design'] !== 'style-5' && $attributes['design'] !== 'style-6') {
            $block_content  =  '<section id="portfolio" class="' . esc_attr( $section_class ) .'">';
            $block_content .= '<div class="' . esc_attr( $containerclass ) .'">';
            $block_content .= '<div class="row">';
            $block_content .= '<div class="col-lg-8 col-md-9 mx-auto text-center">';
            if ( $attributes['displaySectionHeader'] === true ) {
                $block_content .= '<header>';
                $block_content .= '<h1>' . ( isset( $attributes['Title'] ) ?  $attributes['Title'] : (__('Selected works')) ) . '</h1>';
                $block_content .= '<p>' . ( isset( $attributes['Description'] ) ?  $attributes['Description'] : (__('Magnis modipsae voloratati andigen daepeditem quiate re porem que aut labor. Laceaque eictemperum quiae sitiorem rest non restibusaes.')) ) . '</p>';
                $block_content .= '</header>';
            }
            $block_content .= '</div>';
            $block_content .= '</div>';
            $block_content .= '<div class ="row inner-top-sm">';
            $block_content .= '<div class="col-md-12 portfolio">';
            $block_content .= '<ul class= "filter text-center">';
            $block_content .= '<li><a href="#" data-filter="*">All</a></li>';
            $block_content .= wp_kses_post( $singlecat );
            $block_content .= '</ul>';
            $block_content .= '<ul class="' . esc_attr( $ulClass ) . '">';
            $block_content .= wp_kses_post( $posts_markup );
            $block_content .= '</ul>';
            $block_content .= '</div>';
            $block_content .= '</div>';
            $block_content .= '</div>';
            $block_content .= '</section>';
        }
        if ( $attributes['design'] === 'style-5' ) {
            $block_content  =  '<section id="selected-works" class="' . esc_attr( $section_class ) .'">';
            $block_content .= '<div class="portfolio">';
            $block_content .= '<div class="' . esc_attr( $containerclass ) .'">';
            $block_content .= '<ul class= "filter text-center">';
            $block_content .= '<li><a href="#" data-filter="*">All</a></li>';
            $block_content .= wp_kses_post( $singlecat );
            $block_content .= '</ul>';
            $block_content .= '</div>';
            $block_content .= '<ul class="' . esc_attr( $ulClass ) . '">';
            $block_content .= wp_kses_post( $posts_markup );
            $block_content .= '</ul>';
            $block_content .= '</div>';
            $block_content .= '</section>';
        }
        if ( $attributes['design'] === 'style-6' ) {
            $block_content  = '<div class="' . esc_attr( $containerclass ) .'">';
            $block_content .= '<div class="row">';
            $block_content .= wp_kses_post( $posts_markup );
            $block_content .= '</div>';
            $block_content .= '</div>';
        }

        return $block_content;
    }
}


if ( ! function_exists( 'reengb_register_portfolio_block' ) ) {
    /**
     * Registers the `fgb/portfolio` block on server.
     */
    function reengb_register_portfolio_block() {
        if ( ! function_exists( 'register_block_type' ) ) {
            return;
        }

        register_block_type(
            'rgb/portfolio',
            array(
                'attributes' => array(
                    'postsToShow' => array(
                        'type' => 'number',
                        'default' => 7,
                    ),
                    'Title' => array(
                        'type' => 'string',

                    ),
                    'className' => array(
                        'type' => 'string',

                    ),
                    'background' => array(
                        'type'    => 'string',
                        'default' => 'light-bg',

                    ),
                    'Description' => array(
                        'type' => 'string',

                    ),
                    'order' => array(
                        'type' => 'string',
                        'default' => 'desc',
                    ),
                    'orderBy' => array(
                        'type' => 'string',
                        'default' => 'date',
                    ),
                    'design' => array(
                        'type' => 'string',
                        'default' => 'style-1',
                    ),
                    'enableContainer' => array(
                        'type' => 'boolean',
                        'default' => true,
                    ),
                    'displaySectionHeader' => array(
                        'type' => 'boolean',
                        'default' => true,
                    ),
                    'posts'=> array(
                        'type' => 'array',
                        'items' => array(
                          'type' => 'object'
                        ),
                        'default' => [],
                    ),
                    'portfolio_tags'=> array(
                        'type' => 'array',
                        'items' => array(
                          'type' => 'string'
                        ),
                        'default' => [],
                    ),
                ),
                
                'render_callback' => 'reengb_render_portfolio_block',
            )
        );
    }
    add_action( 'init', 'reengb_register_portfolio_block' );
}

if ( ! function_exists( 'reengb_portfolio_rest_fields' ) ) {
    /**
     * Add more data in the REST API that we'll use in the blog post.
     *
     * @since 1.7
     */
    function reengb_portfolio_rest_fields() {

        // Featured image urls.
        register_rest_field( 'jetpack-portfolio', 'featured_image_url',
            array(
                'get_callback' => 'reengb_portfolio_featured_image_urls',
                'update_callback' => null,
                'schema'          => null,
            )
        );

        // Author Name.
        register_rest_field( 'jetpack-portfolio', 'author_info',
            array(
                'get_callback' => 'reengb_portfolio_author_info',
                'update_callback' => null,
                'schema' => array(
                    'description' => __( 'Author information' ),
                    'type' => 'array',
                ),
            )
        );

        //Category name.
        register_rest_field( 'jetpack-portfolio', 'category',
            array(
                'get_callback' => 'reengb_portfolio_category_list',
                'update_callback' => null,
                'schema' => array(
                    'description' => __( 'Category' ),
                    'type' => 'string',
                ),
            )
        );

    }
    add_action( 'init', 'reengb_portfolio_rest_fields' );
}

if ( ! function_exists( 'reengb_portfolio_featured_image_urls' ) ) {
    /**
     * Get the different featured image sizes that the blog will use.
     *
     * @since 1.7
     */
    function reengb_portfolio_featured_image_urls( $object, $field_name, $request ) {
        return get_the_post_thumbnail_url( $object['id'] );
    }
}

if ( ! function_exists( 'reengb_portfolio_author_info' ) ) {
    /**
     * Get the author name and image.
     *
     * @since 1.7
     */
    function reengb_portfolio_author_info( $post ) {

        $portfolio_author = get_post_meta( $post['id'], 'portfolio_byline', true );

        if ( empty( $portfolio_author ) ) {
            $portfolio_author = get_the_author();
        }

        return $portfolio_author;
    }
}

if ( ! function_exists( 'reengb_portfolio_category_list' ) ) {
    /**
     * Get the category.
     *
     * @since 1.7
     */
    function reengb_portfolio_category_list( $items ) {
        $portfolio_type = get_the_terms( get_the_ID(), 'jetpack-portfolio-type' );
        if( is_array( $portfolio_type ) ) return implode('/', wp_list_pluck( $portfolio_type, 'name'));
        return;
    }
}

if ( ! function_exists( 'reengb_rest_jetpack_portfolio_query' ) ) {
    function reengb_rest_jetpack_portfolio_query( $args, $request ) {
        $tax_query = isset( $args['tax_query'] ) ? $args['tax_query'] : array();

        if ( $types = $request->get_param( 'portfolio_types' ) ) {
            $tax_query[] = array(
                'taxonomy' => 'jetpack-portfolio-type',
                'field'    => 'slug',
                'terms'    => $types,
                'operator' => 'IN',
            );
        }

        if ( $tags = $request->get_param( 'portfolio_tags' ) ) {
            $tax_query[] = array(
                'taxonomy' => 'jetpack-portfolio-tag',
                'field'    => 'slug',
                'terms'    => $tags,
                'operator' => 'IN',
            );
        }

        $args['tax_query'] = $tax_query;

        return $args;
    }
}

add_filter( 'rest_jetpack-portfolio_query', 'reengb_rest_jetpack_portfolio_query', 10, 2 );