<?php
/**
 * Server-side rendering of the `rgb/post-carousel` block.
 *
 * @package FrontGB
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Renders the `rgb/post-carousel` block on server.
 *
 * @since 1.7
 *
 * @param array $attributes The block attributes.
 *
 * @return string Returns the post content with latest posts added.
 */
if ( ! function_exists( 'reengb_render_hero_posts_block' ) ) {
    function reengb_render_hero_posts_block( $attributes ) {
        $recent_posts = wp_get_recent_posts(
            array(
                'numberposts' => ! empty( $attributes['postsToShow'] ) ? $attributes['postsToShow'] : '',
                'post_status' => 'publish',
                'order' => ! empty( $attributes['order'] ) ? $attributes['order'] : '',
                'orderby' => ! empty( $attributes['orderBy'] ) ? $attributes['orderBy'] : '',
                'category' => ( ! empty( $attributes['categories'] ) && empty( $attributes['posts'] ) ) ? $attributes['categories'] : '',
                'include'     => ( ! empty( $attributes['posts'] ) && is_array($attributes['posts']) ) ? array_column($attributes['posts'], 'id') : '',
            )
        );

        $posts_markup = '';
        $props = array( 'attributes' => array() );

        $row_classes= '';
        // $carousel_additional_classes = '';

        // if( $attributes['design'] === 'style-1' ) {
        //     $carousel_additional_classes
        // }

        // //Post Categories
        // if ( $attributes['design'] === 'style-1') {
        //     $carousel_classname = 'style-1 owl-outer-nav owl-ui-md owl-item-gap owl-theme';
            
        // } else {
        //     $carousel_classname = 'style-2 owl-theme';
        //     $carousel_classname .= $attributes['enableMargin'] ? ' owl-item-gap' : '' ;
        // }

        $row_classes = ( isset($attributes['rowClasses']) ? $attributes['rowClasses'] : '' ); 

        foreach ( $recent_posts as $post ) {
            $post_id = $post['ID'];

            // Title.
            $post_title = get_the_title( $post_id );

            // Featured image.
            $featured_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post_id ), 'medium' );

            if ( $featured_image ){
                $image ='<img src=' . esc_url($featured_image[0]) . ' alt=""/>';
            } else {
                $image ='<img src="' . untrailingslashit( plugins_url( '/', REENGB_FILE ) ) . '/dist/images/block-post-carousel-work09.2dc6232.jpg' . '" alt="" />';
            }

          
            $post_category = wp_strip_all_tags( get_the_category_list( esc_html__( ', ', 'reengb' ), '', $post_id ), true);    

            // Post Link
            $post_link = get_permalink( $post_id );


            /**
             * This is the default basic style.
             */
            if ( $attributes['design'] === 'style-1') {
                $post_markup  = '<div class="item">';
                $post_markup .= '<figure>';
                $post_markup .= '<div class="icon-overlay icn-link">';
                $post_markup .= '<a href="' . esc_url( $post_link ) . '">';
                $post_markup .= $image;
                $post_markup .= '</a></div>';
                if ($attributes['displayPostTitle'] || $attributes['displayPostCategory'] ) {
                    $post_markup .= '<figcaption class="bordered no-top-border"><div class="info">';
                    if ($attributes['displayPostTitle']) {
                        $post_markup .= '<h4><a href="' . esc_url( $post_link ) . '">' . esc_html( $post_title ) . '</a></h4>';
                    } 
                    if ($attributes['displayPostCategory']) {
                        $post_markup .= '<p>' . wp_kses_post( $post_category ) . '</p>';
                    } 

                    $post_markup .= '</div></figcaption>';
                }
                $post_markup .= '</figure>';
                $post_markup .= '</div>';
                

                // Let others change the saved markup.
                $props = array(
                    'post_id' => $post_id,
                    'attributes' => $attributes,
                );

                $post_markup = apply_filters( 'reengb/post-carousel_save', $post_markup, $attributes, $props );
                $posts_markup .= $post_markup;
            } else if ( $attributes['design'] === 'style-2') {
                $post_markup  = '<div class="item">';
                $post_markup .= '<a href="' . esc_url( $post_link ) . '">';
                $post_markup .= '<figure>';
                if ($attributes['displayPostTitle'] || $attributes['displayPostCategory'] ) {
                    $post_markup .= '<figcaption class="text-overlay"><div class="info">';
                    if ($attributes['displayPostTitle']) {
                        $post_markup .= '<h4>' . esc_html( $post_title ) . '</h4>';
                    } 
                    if ($attributes['displayPostCategory']) {
                        $post_markup .= '<p>' . wp_kses_post( $post_category ) . '</p>';
                    } 
                    $post_markup .= '</div></figcaption>';
                }

                $post_markup .= $image;
                $post_markup .= '</figure>';
                $post_markup .= '</a>';
                $post_markup .= '</div>';
                

                // Let others change the saved markup.
                $props = array(
                    'post_id' => $post_id,
                    'attributes' => $attributes,
                );

                $post_markup = apply_filters( 'reengb/post-carousel_save', $post_markup, $attributes, $props );
                $posts_markup .= $post_markup;
            }
        }


        $block_content  = '<div class="' . esc_attr( $attributes['enableContainer'] ? 'container' : 'no-container' ) . '"><div class="row ' . esc_attr( $row_classes ) .'"><div class="col-md-12"><div id="owl-post-carousel'. uniqid() .'" data-owl-carousel="' . htmlspecialchars( json_encode( $attributes['carouselOptions']), ENT_QUOTES, 'UTF-8' ) . '" class="post-carousel owl-carousel ' . esc_attr( isset( $attributes['carouselOptions']['outerNav']) && !empty( $attributes['carouselOptions']['outerNav']) ? $attributes['carouselOptions']['outerNav'] : '' ) . ' ' . ( isset ( $attributes['carouselOptions']['owlNavSize']) && !empty($attributes['carouselOptions']['owlNavSize']) ? $attributes['carouselOptions']['owlNavSize'] : '' ) . ' ' . esc_attr( isset( $attributes['carouselOptions']['owlItemGap']) && !empty($attributes['carouselOptions']['owlItemGap']) ? $attributes['carouselOptions']['owlItemGap'] : '' ) . '">';
        $block_content .= $posts_markup;
        $block_content .= '</div></div></div></div>';

        return $block_content;

    }
}

if ( ! function_exists( 'reengb_register_hero_posts_block' ) ) {
    /**
     * Registers the `rgb/post-carousel` block on server.
     */
    function reengb_register_hero_posts_block() {
        if ( ! function_exists( 'register_block_type' ) ) {
            return;
        }

        register_block_type(
            'rgb/post-carousel',
            array(
                'attributes' => array(
                    'className' => array(
                        'type' => 'string',
                    ),
                    'enableContainer' => array (
                        'type' => 'boolean',
                        'default' => true,
                    ),
                    'design' => array (
                        'type' => 'string',
                        'default' => 'style-1',
                    ),
                    'order' => array(
                        'type' => 'string',
                        'default' => 'desc',
                    ),
                    'orderBy' => array(
                        'type' => 'string',
                        'default' => 'date',
                    ),

                    'categories' => array (
                        'type' => 'array',
                        'items' => array(
                            'type' => 'number'
                        ),
                        'default' =>[],
                        
                    ),
                    'postsToShow' => array(
                        'type' => 'number',
                        'default' => 9,
                    ),
                    'displayPostTitle' => array(
                        'type' => 'boolean',
                        'default' => true,
                    ),
                    'displayPostCategory' => array(
                        'type' => 'boolean',
                        'default' => true,
                    ),
                    'enableMargin' => array(
                        'type' => 'boolean',
                        'default' => true,
                    ),
                    'posts'=> array(
                        'type' => 'array',
                        'items' => array(
                          'type' => 'object'
                        ),
                        'default' => array(),
                    ),
                    'rowClasses' => array(
                        'type' => 'string',
                    ),
                    
                    'carouselOptions'=> array (
                        'type'      => 'object',
                        'default'   => array(
                            'autoplay'    => true,
                            'autoplayTimeout'       => 5000,
                            'autoplayHoverPause'   => true,
                            'rewind'         => true,
                            'dots'           => true,
                            'nav'            => true,
                            'navText'        => array( '<i class="icon-left-open-mini"></i>', '<i class="icon-right-open-mini"></i>'),
                            'items'         => 5,
                            'responsive'    => array(
                                '0'         => array( 'items' => 1 ),
                                '480'       => array( 'items' => 2 ),
                                '768'       => array( 'items' => 2 ),
                                '992'       => array( 'items' => 3 ),
                                '1200'      => array( 'items' => 5 ),
                            ),
                            'outerNav' => 'owl-outer-nav',
                            'owlNavSize' => 'owl-ui-md',
                            'owlItemGap' => 'owl-item-gap',
                        ),
                    ),
                    
                ),
                'render_callback' => 'reengb_render_hero_posts_block',
            )
        );
    }
    add_action( 'init', 'reengb_register_hero_posts_block' );
}

if ( ! function_exists( 'reengb_post_carousel_rest_fields' ) ) {
    /**
     * Add more data in the REST API that we'll use in the blog post.
     *
     * @since 1.7
     */
    function reengb_post_carousel_rest_fields() {

        // Featured image urls.
        register_rest_field( 'post', 'featured_image_urls',
            array(
                'get_callback' => 'reengb_post_carousel_featured_image_urls',
                'update_callback' => null,
                'schema' => array(
                    'description' => __( 'Different sized featured images' ),
                    'type' => 'array',
                ),
            )
        );
    }

        //Category name.
        register_rest_field( 'post', 'category',
            array(
                'get_callback' => 'reengb_post_carousel_category_list',
                'update_callback' => null,
                'schema' => array(
                    'description' => __( 'Category' ),
                    'type' => 'string',
                ),
            )
        );

        //Category link.
        register_rest_field( 'post', 'category_link',
            array(
                'get_callback' => 'reengb_post_carousel_category_link',
                'update_callback' => null,
                'schema' => array(
                    'description' => __( 'Category' ),
                    'type' => 'object',
                ),
            )
        );
    add_action( 'rest_api_init', 'reengb_post_carousel_rest_fields' );
}

if ( ! function_exists( 'reengb_post_carousel_featured_image_urls' ) ) {
    /**
     * Get the different featured image sizes that the blog will use.
     *
     * @since 1.7
     */
    function reengb_post_carousel_featured_image_urls( $object, $field_name, $request ) {
        $image = wp_get_attachment_image_src( $object['featured_media'], 'full', false );
        return array(
            'full' => is_array( $image ) ? $image : '',
        );
    }
}

if ( ! function_exists( 'reengb_post_carousel_category_list' ) ) {
    /**
     * Get the category.
     *
     * @since 1.7
     */
    function reengb_post_carousel_category_list( $object ) {
        return implode(', ', wp_list_pluck(get_the_category( $object['id'] ), 'name'));
    }
}

if ( ! function_exists( 'reengb_post_carousel_category_link' ) ) {
    /**
     * Get the category.
     *
     * @since 1.7
     */
    function reengb_post_carousel_category_link( $object ) {
        $categories = get_the_category( $object['id'] );

        $categories_list = array();

        if (! empty($categories) ) {
            foreach ($categories as $category) {
                $categories_list[] = array(
                    'link' => get_term_link( $category ),
                );
            }
        }

        return wp_list_pluck( $categories_list, 'link');
    }
}


