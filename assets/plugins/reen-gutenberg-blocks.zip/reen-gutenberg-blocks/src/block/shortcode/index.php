<?php
/**
 * Server-side rendering of the `rgb/shortcode` block.
 *
 * @package ReenGB
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Renders the `rgb/shortcode` block on server.
 *
 * @since 1.0
 *
 * @param array $attributes The block attributes.
 *
 * @return string Returns the post content with latest posts added.
 */
if ( ! function_exists( 'reengb_render_shortcode_block' ) ) {
    function reengb_render_shortcode_block( $attributes ) {
        return ! empty( $attributes['text'] ) ? do_shortcode( $attributes['text'] ) : '';
    }
}

if ( ! function_exists( 'reengb_register_shortcode_block' ) ) {
    /**
     * Registers the `rgb/shortcode` block on server.
     */
    function reengb_register_shortcode_block() {
        if ( ! function_exists( 'register_block_type' ) ) {
            return;
        }

        register_block_type(
            'rgb/shortcode',
            array(
                'attributes'      => array(
                    'label' => array(
                        'type'   => 'string'
                    ),
                    'placeholder' => array(
                        'type'   => 'string'
                    ),
                    'text' => array(
                        'type'   => 'string'
                    ),
                ),
                'render_callback' => 'reengb_render_shortcode_block',
            )
        );
    }
    add_action( 'init', 'reengb_register_shortcode_block' );
}